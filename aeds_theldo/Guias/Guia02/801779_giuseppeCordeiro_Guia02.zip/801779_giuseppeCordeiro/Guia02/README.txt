theldo, aqui estao as atividades do Guia02 numeradas por data e ordem de serem feitas

Guia0201 07/08
Guia0202 07/08
Guia0203 07/08
Guia0204 07/08
Guia0205 07/08
Guia0206 07/08
Guia0207 07/08
Guia0208 07/08
Guia0209 07/08
Guia0210 07/08
Guia0211 07/08
Guia0212 07/08
Guia0213 07/08


sem presentes duvidas ate o momento


Guia0214 08/08
Guia0215 08/08
Guia02E1 08/08
Guia02E2 08/08
